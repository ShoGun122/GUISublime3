import javax.swing.*;
import javax.swing.table.AbstractTableModel;

public class ImgTableModel extends AbstractTableModel {
    private String [] cols = {"Path","Author","Date","Location","Tags"};
    private Object [][] tableValues ;

    public int getColumnCount() {
        return cols.length;
    }

    public int getRowCount() {
        return tableValues.length;
    }

    public String getColumnName(int col) {
        return cols[col];
    }

    public Object getValueAt(int row, int col) {
        return tableValues[row][col];
    }


}
