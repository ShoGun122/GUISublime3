import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main (String [] args) throws FileNotFoundException
    {
        test();
    }
    public static void test () throws FileNotFoundException {
        JFrame mainFrame = new JFrame();
        Dimension nDim = Toolkit.getDefaultToolkit().getScreenSize();
        mainFrame.setSize(nDim.width/2,nDim.height/2);
        mainFrame.setLocation(nDim.width/4,nDim.height/4);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel();
        // String columns [] = {"Path","Author","Data","Location","Tags"};
        Object data= new  Object[15][5];
        // JTable table = new JTable(new DefaultTableModel(new Object[] {"Path","Author","Data","Location","Tags"}));
        DefaultTableModel model = new DefaultTableModel();
        JTable table = new JTable(model);
        model.addColumn("Path");
        model.addColumn("Author");
        model.addColumn("Data");
        model.addColumn("Location");
        model.addColumn("Tags");
        JScrollPane scrollPane = new JScrollPane(table);
        float wid = nDim.width/2;
        scrollPane.setPreferredSize(new Dimension(nDim.width/3,200));
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        JTextField path = new JTextField (100);
        JTextField author = new JTextField (100);
        JTextField date = new JTextField (100);
        JTextField tags = new JTextField (100);
        JTextField location = new JTextField (100);
        JLabel pathT = new JLabel("Path");
        JLabel authorT = new JLabel("Author");
        JLabel dateT = new JLabel("Data");
        JLabel locationT = new JLabel("Location");
        JLabel tagsT = new JLabel("Tags");
        panel.add(pathT);
        panel.add(path);
        panel.add(authorT);
        panel.add(author);
        panel.add(dateT);
        panel.add(date);
        panel.add(tagsT);
        panel.add(tags);
        panel.add(locationT);
        panel.add(location);
        panel.add(scrollPane);
        JButton save = new JButton("save");
        JButton export = new JButton("Export to txt");
        JButton importbtn = new JButton("Import from txt");
        panel.add(save);
        panel.add(export);
        panel.add(importbtn);
        JLabel test = new JLabel();
        panel.add(test);
        mainFrame.setContentPane(panel);
        mainFrame.setVisible(true);

        /// SAVING FRAME

        JFrame savingWindow = new JFrame();
        savingWindow.setSize(500,300);
        savingWindow.setLocation(nDim.width/4,nDim.height/4);
        JButton saveWindowButton = new JButton("Export");
        JLabel chooseName = new JLabel("ChosePath");
        JTextField exportFilePath = new JTextField(40);
        JPanel saveWindowPanel =new JPanel();
        saveWindowPanel.add(chooseName);
        saveWindowPanel.add(exportFilePath);
        saveWindowPanel.add(saveWindowButton);
        savingWindow.add(saveWindowPanel);

        saveWindowButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String pathToSave = exportFilePath.getText();
                File tableDatabase = new File(pathToSave);
                PrintWriter saveDatatoDatabase = null;
                try {
                    saveDatatoDatabase = new PrintWriter(tableDatabase);
                    for (int row = 0; row < model.getRowCount(); row++)
                    {
                        String value = "";
                        for (int col = 0; col < model.getColumnCount(); col++)
                        {
                            value = value + model.getValueAt(row, col) + " | ";
                        }
                        saveDatatoDatabase.println(value);

                    }saveDatatoDatabase.close();
                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                }
                savingWindow.setVisible(false);
            }
        });




        //JScrollPane allScrollPane = new ScrollPane();
        save.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                String newRow [] = {path.getText(),author.getText(),date.getText(),location.getText(),tags.getText()};
                model.addRow(newRow);
            }
        });
        export.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                savingWindow.setVisible(true);
            }
        });importbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooseFileToImport = new JFileChooser();
                int check = chooseFileToImport.showOpenDialog(mainFrame);
                if(check == JFileChooser.APPROVE_OPTION)
                {
                    String databasePath = chooseFileToImport.getSelectedFile().getPath();
                    File file = new File(databasePath);
                    try {
                        Scanner importDataFromDatabse = new Scanner(file);

                        while (importDataFromDatabse.hasNextLine()) {


                            String rowValue = importDataFromDatabse.nextLine();
                            System.out.println(rowValue);
                            String tableRowToImport[] = rowValue.split(",");
                            for(int x = 0 ;  x < 5 ; x++)
                            {
                                System.out.print(tableRowToImport[x]);
                            }
                            System.out.println("===");
                            model.addRow(tableRowToImport);

                        }
                        ;
                    }
                    catch (Exception ex) {
                        ex.printStackTrace();
                    }

                }
            }
        });

    }
}
